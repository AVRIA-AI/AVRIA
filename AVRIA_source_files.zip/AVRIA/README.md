# AVRIA AI Trading Platform

AVRIA is an early-stage Telegram Mini App and demo-trading backend.

## Included
- FastAPI backend and SQLite demo account storage
- $10,000 starting virtual balance
- Demo BUY/SELL positions
- Portfolio and trade history
- Close demo positions with manually entered simulated P/L
- Responsive Mini App interface

## Run locally
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
uvicorn app:app --reload
```
Open http://127.0.0.1:8000

## Important limitations
This version is a demo simulator only. It does not connect to exchanges, execute real trades, fetch live prices, or generate AI signals. The P/L entered when closing a position is simulated by the user. Development authentication is enabled by default; do not deploy publicly until Telegram Mini App `initData` verification and production configuration are implemented.

Never commit `.env` or publish your Telegram bot token.
